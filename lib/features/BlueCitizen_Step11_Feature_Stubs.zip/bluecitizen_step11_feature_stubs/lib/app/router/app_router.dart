import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/app_shell.dart';
import 'package:blue_citizen/app/router/app_routes.dart';

import 'package:blue_citizen/features/map/map_routes.dart';
import 'package:blue_citizen/features/events/events_routes.dart';
import 'package:blue_citizen/features/report/report_routes.dart';
import 'package:blue_citizen/features/community/community_routes.dart';
import 'package:blue_citizen/features/profile/profile_routes.dart';
import 'package:blue_citizen/features/notifications/notifications_routes.dart';
import 'package:blue_citizen/features/settings/settings_routes.dart';
import 'package:blue_citizen/features/donate/donate_routes.dart';
import 'package:blue_citizen/features/dashboard/dashboard_routes.dart';
import 'package:blue_citizen/features/admin/admin_routes.dart';
import 'package:blue_citizen/features/knowledge/knowledge_routes.dart';

/// Main application router.
///
/// Tab order is Map, Events, Report, Community, Profile.
/// Keep this order synchronized with the tab indexes in AppRoutes and AppShell.
final GoRouter appRouter = GoRouter(
  navigatorKey: rootNavigatorKey,
  initialLocation: AppRoutes.map,
  routes: <RouteBase>[
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) {
        return AppShell(navigationShell: navigationShell);
      },
      branches: <StatefulShellBranch>[
        mapTabRoute, // index 0
        eventsTabRoute, // index 1
        reportTabRoute, // index 2
        communityTabRoute, // index 3
        profileTabRoute, // index 4
      ],
    ),

    // Future detail routes for tab features. Their root paths are already
    // registered inside the StatefulShellRoute branches above.
    ...mapRoutes,
    ...eventsRoutes,
    ...reportRoutes,
    ...communityRoutes,
    ...profileRoutes,

    // Standalone screens, outside the five-tab scaffold.
    ...notificationsRoutes,
    ...settingsRoutes,
    ...donateRoutes,
    ...dashboardRoutes,
    ...adminRoutes,
    ...knowledgeRoutes,
  ],
);
