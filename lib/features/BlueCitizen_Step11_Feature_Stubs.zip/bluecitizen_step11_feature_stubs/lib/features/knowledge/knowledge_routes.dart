import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/knowledge_screen.dart';

/// Standalone routes owned by the Knowledge feature.
final List<RouteBase> knowledgeRoutes = <RouteBase>[
  GoRoute(
    path: AppRoutes.knowledge,
    builder: (context, state) => const KnowledgeScreen(),
  ),
];
