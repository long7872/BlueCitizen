import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/settings_screen.dart';

/// Standalone routes owned by the Settings feature.
final List<RouteBase> settingsRoutes = <RouteBase>[
  GoRoute(
    path: AppRoutes.settings,
    builder: (context, state) => const SettingsScreen(),
  ),
];
