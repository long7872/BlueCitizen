import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/map_screen.dart';

/// The Map tab branch. Keep its position consistent with AppRoutes tab indexes.
final StatefulShellBranch mapTabRoute = StatefulShellBranch(
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.map,
      builder: (context, state) => const MapScreen(),
    ),
  ],
);

/// Add Map/Events/Report/Community/Profile detail routes here when needed.
/// The tab's root path is already registered in mapTabRoute above.
const List<RouteBase> mapRoutes = <RouteBase>[];
