# Report Feature

## Purpose

This folder contains the temporary navigation stub for the **Report** feature.
The stub lets the team verify routing before the real UI and business logic are implemented.

## Files

- `screens/report_screen.dart` — declares `ReportScreen` and returns `PlaceholderScreen` from `build()`.
- `report_routes.dart` — registers this feature with GoRouter.

## Ownership

Current placeholder owner: **Report Team**. Replace this label with the agreed team member or sub-team when ownership is finalized.

## Navigation links

- Back to Map → `AppRoutes.map` (go)
- Explore Events → `AppRoutes.events` (go)

## Implementation notes

- Keep feature-specific screens and routes inside this feature folder.
- Do not register the same root path a second time in `app_router.dart`.
- For a tab feature, keep the root `GoRoute` inside its `StatefulShellBranch`. Add detail routes to the exported `xxxRoutes` list.
- For a standalone feature, add its routes to the exported `xxxRoutes` list.
