import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/report_screen.dart';

/// The Report tab branch. Keep its position consistent with AppRoutes tab indexes.
final StatefulShellBranch reportTabRoute = StatefulShellBranch(
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.reportNew,
      builder: (context, state) => const ReportScreen(),
    ),
  ],
);

/// Add Map/Events/Report/Community/Profile detail routes here when needed.
/// The tab's root path is already registered in reportTabRoute above.
const List<RouteBase> reportRoutes = <RouteBase>[];
