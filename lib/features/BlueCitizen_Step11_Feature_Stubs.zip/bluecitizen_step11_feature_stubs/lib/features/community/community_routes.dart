import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/community_screen.dart';

/// The Community tab branch. Keep its position consistent with AppRoutes tab indexes.
final StatefulShellBranch communityTabRoute = StatefulShellBranch(
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.community,
      builder: (context, state) => const CommunityScreen(),
    ),
  ],
);

/// Add Map/Events/Report/Community/Profile detail routes here when needed.
/// The tab's root path is already registered in communityTabRoute above.
const List<RouteBase> communityRoutes = <RouteBase>[];
