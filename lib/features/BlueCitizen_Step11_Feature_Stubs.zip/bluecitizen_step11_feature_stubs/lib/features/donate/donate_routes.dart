import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/donate_screen.dart';

/// Standalone routes owned by the Donate feature.
final List<RouteBase> donateRoutes = <RouteBase>[
  GoRoute(
    path: AppRoutes.donate,
    builder: (context, state) => const DonateScreen(),
  ),
];
