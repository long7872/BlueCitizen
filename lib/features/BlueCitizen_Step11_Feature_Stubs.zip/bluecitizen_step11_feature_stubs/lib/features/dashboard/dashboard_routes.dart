import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/dashboard_screen.dart';

/// Standalone routes owned by the Dashboard feature.
final List<RouteBase> dashboardRoutes = <RouteBase>[
  GoRoute(
    path: AppRoutes.dashboard,
    builder: (context, state) => const DashboardScreen(),
  ),
];
