import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/notifications_screen.dart';

/// Standalone routes owned by the Notifications feature.
final List<RouteBase> notificationsRoutes = <RouteBase>[
  GoRoute(
    path: AppRoutes.notifications,
    builder: (context, state) => const NotificationsScreen(),
  ),
];
