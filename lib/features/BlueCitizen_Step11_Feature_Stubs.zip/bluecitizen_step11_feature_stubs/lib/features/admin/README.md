# Admin Feature

## Purpose

This folder contains the temporary navigation stub for the **Admin** feature.
The stub lets the team verify routing before the real UI and business logic are implemented.

## Files

- `screens/admin_screen.dart` — declares `AdminScreen` and returns `PlaceholderScreen` from `build()`.
- `admin_routes.dart` — registers this feature with GoRouter.

## Ownership

Current placeholder owner: **Admin Team**. Replace this label with the agreed team member or sub-team when ownership is finalized.

## Navigation links

- Back to Dashboard → `AppRoutes.dashboard` (go)
- Open Reports → `AppRoutes.reportNew` (go)

## Implementation notes

- Keep feature-specific screens and routes inside this feature folder.
- Do not register the same root path a second time in `app_router.dart`.
- For a tab feature, keep the root `GoRoute` inside its `StatefulShellBranch`. Add detail routes to the exported `xxxRoutes` list.
- For a standalone feature, add its routes to the exported `xxxRoutes` list.
