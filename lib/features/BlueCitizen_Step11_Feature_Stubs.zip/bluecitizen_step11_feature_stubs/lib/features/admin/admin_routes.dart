import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/admin_screen.dart';

/// Standalone routes owned by the Admin feature.
final List<RouteBase> adminRoutes = <RouteBase>[
  GoRoute(
    path: AppRoutes.admin,
    builder: (context, state) => const AdminScreen(),
  ),
];
