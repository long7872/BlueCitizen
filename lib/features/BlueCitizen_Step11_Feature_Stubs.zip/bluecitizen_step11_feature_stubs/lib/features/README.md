# Features Folder — BlueCitizen

This folder groups the app by feature. Each feature owns its screen entry point and GoRouter declarations.

## Feature inventory

| Feature | Entry screen | Route file | Navigation type |
|---|---|---|---|
| Map | `map/screens/map_screen.dart` | `map/map_routes.dart` | Stateful tab, index 0 |
| Events | `events/screens/events_screen.dart` | `events/events_routes.dart` | Stateful tab, index 1 |
| Report | `report/screens/report_screen.dart` | `report/report_routes.dart` | Stateful tab, index 2 |
| Community | `community/screens/community_screen.dart` | `community/community_routes.dart` | Stateful tab, index 3 |
| Profile | `profile/screens/profile_screen.dart` | `profile/profile_routes.dart` | Stateful tab, index 4 |
| Notifications | `notifications/screens/notifications_screen.dart` | `notifications/notifications_routes.dart` | Standalone route |
| Settings | `settings/screens/settings_screen.dart` | `settings/settings_routes.dart` | Standalone route |
| Donate | `donate/screens/donate_screen.dart` | `donate/donate_routes.dart` | Standalone route |
| Dashboard | `dashboard/screens/dashboard_screen.dart` | `dashboard/dashboard_routes.dart` | Standalone route |
| Admin | `admin/screens/admin_screen.dart` | `admin/admin_routes.dart` | Standalone route |
| Knowledge | `knowledge/screens/knowledge_screen.dart` | `knowledge/knowledge_routes.dart` | Standalone route |

## Feature folder convention

```text
feature_name/
├── screens/
│   └── feature_name_screen.dart
├── feature_name_routes.dart
└── README.md
```

The screen class is named `FeatureNameScreen`. During this setup phase, its `build()` method returns `PlaceholderScreen` and supplies one or two `PlaceholderLink` values. Links are deliberately cross-feature so the team can test the route graph.

## Routing rules

- Register persistent tabs as `StatefulShellBranch` values in `app_router.dart`.
- Register tab root paths only once, inside their branch.
- Keep future detail routes in the feature's exported `xxxRoutes` list.
- Register secondary modules as standalone routes and spread their route lists into the root `GoRouter.routes` collection.
- Use `context.go()` to switch tabs or replace the current location. Use `context.push()` when the user should be able to return to the previous screen with Back.
- Keep the tab order consistent across `AppRoutes`, `AppShell`, and `app_router.dart`.

## Shared dependencies

Feature stubs depend on:

- `package:flutter/material.dart`
- `package:go_router/go_router.dart`
- `package:blue_citizen/app/router/app_routes.dart`
- `package:blue_citizen/core/widgets/placeholder_screen.dart`

The shared `PlaceholderScreen` owns the `Scaffold`, top bar, and placeholder layout. Feature screens should not wrap it in a second `Scaffold`.
