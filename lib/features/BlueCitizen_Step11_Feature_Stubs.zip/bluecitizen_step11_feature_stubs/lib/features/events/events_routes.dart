import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/events_screen.dart';

/// The Events tab branch. Keep its position consistent with AppRoutes tab indexes.
final StatefulShellBranch eventsTabRoute = StatefulShellBranch(
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.events,
      builder: (context, state) => const EventsScreen(),
    ),
  ],
);

/// Add Map/Events/Report/Community/Profile detail routes here when needed.
/// The tab's root path is already registered in eventsTabRoute above.
const List<RouteBase> eventsRoutes = <RouteBase>[];
