import 'package:go_router/go_router.dart';

import 'package:blue_citizen/app/router/app_routes.dart';
import 'screens/profile_screen.dart';

/// The Profile tab branch. Keep its position consistent with AppRoutes tab indexes.
final StatefulShellBranch profileTabRoute = StatefulShellBranch(
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.profile,
      builder: (context, state) => const ProfileScreen(),
    ),
  ],
);

/// Add Map/Events/Report/Community/Profile detail routes here when needed.
/// The tab's root path is already registered in profileTabRoute above.
const List<RouteBase> profileRoutes = <RouteBase>[];
