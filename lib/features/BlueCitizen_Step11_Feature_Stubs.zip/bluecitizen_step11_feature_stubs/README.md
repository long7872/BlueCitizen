# BlueCitizen — Step 11: Feature Stubs and Route Registration

This package contains the initial screen stubs and GoRouter registrations for all 11 BlueCitizen features.
It is designed to be merged into the existing Flutter project; it is not a standalone Flutter app.

## Included structure

```text
lib/
├── app/
│   └── router/
│       └── app_router.dart
└── features/
    ├── map/
    ├── events/
    ├── report/
    ├── community/
    ├── profile/
    ├── notifications/
    ├── settings/
    ├── donate/
    ├── dashboard/
    ├── admin/
    └── knowledge/
```

Every feature folder contains:

- `screens/xxx_screen.dart` — a `StatelessWidget` named `XxxScreen`; `build()` returns `PlaceholderScreen` with two navigation links.
- `xxx_routes.dart` — the feature's GoRouter route declaration(s).
- `README.md` — purpose, files, owner placeholder, navigation links, and implementation notes.

There is also `lib/features/README.md`, which describes the complete features folder.

## Tab and standalone route design

The five persistent tabs are registered as `StatefulShellBranch` objects, in this exact order:

| Index | Tab | Route constant |
|---:|---|---|
| 0 | Map | `AppRoutes.map` |
| 1 | Events | `AppRoutes.events` |
| 2 | Report | `AppRoutes.reportNew` |
| 3 | Community | `AppRoutes.community` |
| 4 | Profile | `AppRoutes.profile` |

Notifications, Settings, Donate, Dashboard, Admin, and Knowledge are standalone GoRouter routes outside the shell.
Their navigation can cover the tab scaffold; `context.go()` returns to a tab and `context.push()` opens a standalone page on top of the current location.

## Existing project requirements

This bundle intentionally reuses the APIs created in earlier BlueCitizen steps. Before copying, make sure the project already contains:

1. `lib/core/widgets/placeholder_screen.dart`, exporting `PlaceholderScreen` and `PlaceholderLink`.
2. `lib/app/app_shell.dart`, exporting `AppShell(navigationShell: ...)`.
3. `lib/app/router/app_routes.dart`, exporting `rootNavigatorKey` and these route constants:
   - `map`, `events`, `reportNew`, `community`, `profile`
   - `notifications`, `settings`, `donate`, `dashboard`, `admin`, `knowledge`
4. `go_router` in `pubspec.yaml`.

The `PlaceholderScreen` API expected by these stubs is:

```dart
PlaceholderScreen(
  title: 'Map',
  owner: 'Map Team',
  links: [
    PlaceholderLink(
      label: 'Open Events',
      onTap: () => context.go(AppRoutes.events),
    ),
  ],
)
```

`PlaceholderLink` must accept `label` and `onTap`. This matches the Core Widgets package from Step 6.

## Integration

1. Back up the current `lib/app/router/app_router.dart`.
2. Copy the package's `lib/features/` into the project's `lib/features/`.
3. Replace the project's `lib/app/router/app_router.dart` with this bundle's version. This is the final planned edit to `app_router.dart` for Step 11.
4. Keep the existing `app_routes.dart`; this bundle does not replace it.
5. Run:

```bash
flutter pub get
flutter analyze
flutter run
```

## Important routing notes

- Do not add the five tab root paths again as top-level `GoRoute`s. They are already registered inside the corresponding `StatefulShellBranch`.
- The `mapRoutes`, `eventsRoutes`, `reportRoutes`, `communityRoutes`, and `profileRoutes` lists are intentionally empty extension points for future detail pages. Add details there, not duplicate tab roots.
- The six standalone route lists contain their feature's initial route.
- The Report tab is index `2`. The central action button in `AppShell` should select this branch with `navigationShell.goBranch(2, initialLocation: true)` rather than pushing a second copy of Report Home.
- For nested report-form steps or full-screen detail routes, register the relevant child/detail route in the Report feature and use the root navigator when the page must cover the tab scaffold.
- The temporary links use `go()` to switch tabs and `push()` to open standalone screens. Change those calls only when the intended back-stack behavior is different.

## Ownership

The owner labels such as `Map Team` and `Report Team` are placeholders. Replace them with the agreed names from the team. They do not affect runtime behavior.

## What this step does not implement

No business logic, API calls, Firebase integration, permission checks, form validation, map rendering, or final visual design is included. Each screen is a navigation placeholder so the full route graph can be smoke-tested before feature work begins.
