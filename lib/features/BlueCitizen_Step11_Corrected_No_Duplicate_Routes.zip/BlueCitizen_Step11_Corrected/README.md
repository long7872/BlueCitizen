# BlueCitizen — Step 11 (Corrected): Feature Screen Stubs

This is the corrected Step 11 package. It adds the 11 feature screen stubs and English documentation while preserving the routing files already present in the project.

## Important correction

Your project already contains 11 route files under `lib/app/router/features/`. Therefore this package deliberately excludes:

- all `*_routes.dart` files;
- `lib/app/router/app_router.dart`;
- `lib/app/router/app_routes.dart`.

This avoids duplicate route declarations and prevents replacing your existing router. The existing route files should import and construct the matching screen classes under `lib/features/<feature>/screens/`.

## Included

- 11 `screens/<feature>_screen.dart` files, each defining a `StatelessWidget` stub;
- 11 feature-level `README.md` files;
- `lib/features/README.md`, describing the whole feature folder and integration contract.

## Copy into your project

Copy the `lib/features/` directory from this package into the root of your BlueCitizen project. Merge it with your existing `lib/features/` directory rather than replacing unrelated files.

Do **not** copy any router files from this package; none are included. Keep the route files in `lib/app/router/features/` as the only route definitions.

## After copying

Check each existing route declaration points to its matching screen class, then run:

```bash
flutter pub get
flutter analyze
flutter run
```

## Dependencies / assumptions

- Dart package name: `blue_citizen`.
- `go_router` is already installed.
- Existing shared widget: `PlaceholderScreen` and `PlaceholderLink` in `lib/core/widgets/placeholder_screen.dart`.
- Existing route constants: `AppRoutes.map`, `events`, `reportNew`, `community`, `profile`, `notifications`, `settings`, `donate`, `dashboard`, `admin`, and `knowledge`.

No business logic, final UI, backend integration, or feature data layer is included in this step.
